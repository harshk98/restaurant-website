$(function() {
	$("#navbarToggle").blur(function(event) {
		var width=window.innerWidth;
		if(width<768){
			$("#collapseable-nav").collapse('hide');
		}
	});
});
$(function() {
	// body...
  var switchMenuToActive = function () {
  // Remove 'active' from home button
  var classes = document.querySelector("#navHomeButton").className;
  classes = classes.replace(new RegExp("active", "g"), "");
  document.querySelector("#navHomeButton").className = classes;

  // Add 'active' to menu button if not already there
  classes = document.querySelector("#navMenuButton").className;
  if (classes.indexOf("active") == -1) {
    classes += " active";
    document.querySelector("#navMenuButton").className = classes;
  }
};
});

 $(document).ready(function(){
  $("#submit").click(function(){
    var fname = $("#fname").val();
    var lname = $("#lname").val();
    var email = $("#email").val();
    var sel = $("#sel").val();
    var text=$("#subject").val();
    var flag=0;
              $(".error").remove();
    if (fname.length < 1) {
      $('#fname').after('<span class="error">This field is required </span>');
      flag=1;
    }
    if (lname.length < 1) {
      $('#lname').after('<span class="error">This field is required </span>');
      flag=1;
    }
    if (email.length < 1) {
      $('#email').after('<span class="error">This field is required </span>');
      flag=1;
    }
    else {
      var regEx =/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
      var validEmail = regEx.test(email);
      if (!validEmail) {
        $('#email').after('<span class="error">Enter a Valid Email id </span>');
        flag=1;
      }
    }
    if (sel.length < 1) {
      $('#sel').after('<span class="error">This field is required </span>');
      flag=1;
    }
    if(text.length<1)
       {
      $('#subject').after('<span class="error">This field is required </span>');
      flag=1;
    }
    if(flag==0){
      document.getElementById('fname').value="";
      document.getElementById('lname').value="";
      document.getElementById('email').value="";
      document.getElementById('sel').value="";
      document.getElementById('subject').value="";
      alert("SUCCEFULLY SUBMITTED");
     
    }
  });
});
